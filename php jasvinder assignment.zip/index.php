<!DOCTYPE html>
<html>
<head>
  <title>Driving Licence Form</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="CSS/Style.css">

</head>
<header>
      <nav>
				<ul>
        <img src="images/logotwo.jpg" alt="logo imahe" height="50px" width="50px" />
        <li><a href="index.php" title="Go to the Home page">Home</a></li>
        <li><a href="theview.php" title="Go to the view page">View</a></li>
        </ul>
			</nav>
</header>
<body>
      
  <h1>Driving Licence Form</h1>


  <?php
    echo "<h1><center>Enter New Candidate detail</center></h1>";
  ?>

  <form action="view.php" method="post">
<center>
    <label for="name">Customer Name:</label>
    <input type="text" id="name" name="name" required><br><br>

    <label for="number">Customer Detail:</label>
    <input type="text" id="number" name="number" required><br><br>

    <input type="submit" name="submit" value="Submit">
</center>
  </form>
  
</body>
<footer>
  <small>@ A WEBSITE BY JASVINDER KAUR</small>
</footer>
</html>
