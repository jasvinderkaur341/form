<html>
    <head>
        <title>Driving License Form</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="CSS/Style.css">
    </head>
    <body>
        <nav>
	    	<ul>
                <img src="images/logotwo.jpg" alt="logo imahe" height="50px" width="50px" />
                <li><a href="index.php" title="Go to the Home page">Home</a></li>
                <li><a href="theview.php" title="Go to the view page">View</a></li>
            </ul>
		</nav>
    </body>
    <footer>
        <small>@ A WEBSITE BY JASVINDER KAUR</small>
    </footer>
</html>    
    <?php
    if(isset($_POST['submit']))
    {
        $sName = $_POST['name'];
        $sNumber = $_POST['number'];
    }

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "jasvinder";

    //creating connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    if(!$con){
        die("Connection Failed" . mysqli_connect_error());
    }

    $sql = "INSERT INTO sinfo (sName, sNumber) VALUES ('$sName', '$sNumber')";

    $rs = mysqli_query($con, $sql);

    if($rs){
        echo "Entries Added Successfully....";
    }

    mysqli_close($con);
    ?>

  